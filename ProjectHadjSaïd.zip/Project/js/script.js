var karray = ['1','2','3','4','5','6','7','8','9','10','11','12','1','2','3','4','5','6','7','8','9','10','11','12'];
var larray = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16'];
var Waarde = [];
var nrKaart = [];
var KaartOmgedraaid = 0;
var bcksound  = new Audio("../img/son.mp3");
var on = true;
bcksound.volume = 0.5;
bcksound.play();
var score = 0;

/* ************************
HIER TOON IK AAN DAT IK MUSIC KAN TOEVOEGEN/DEZE FUNCTIE WERKT OOK...
*************************** */

$(function musiconoff()
{
    $("#music").click(function() {
    if (on)
	{		
		bcksound.pause();
		document.getElementById("music").style.backgroundImage = 'url("../img/soundon.png")';
		on = false;
	}
	else
	{
		bcksound.play();
		bcksound.currentTime = 0;
		document.getElementById("music").style.backgroundImage = 'url("../img/soundoff.png")';
		on = true;
	}
        
    })
})

/* ******************
    HIER LUKT IETS NIET
    IK WOU GEBRUIK MAKEN VAN JQUERRY OM ZE 1 NA 1 TE LATEN APPEND IN DE DAARVOOR GEMAAKTE ZONE ...
*********************
var lives =0;

function getlives(){
    for(lives = 0, lives<3, lives++)
    {
        var heart ='<div id= "lives"></div>';
        $("#liveArea").append(heart);
    }
}
*/
/* ****************** 
    DEZE FUNCTION GEBRUIK IK VOOR HET VERDELEN VAN DE KAARTEN
***************** */

Array.prototype.Verdeel = function(){
    
    var i = this.length, j, temp;
    while(--i > 0){
        j = Math.floor(Math.random() * (i+1));
        temp = this[j];
        this[j] = this[i];
        this[i] = temp;
    }
}

/* ******************
    HIER LUKT IETS NIET
*********************
function Score()
{
   if(Waarde[0] == Waarde[1])
        {
       score = (score-10);
        }
    else
        {
        score =(score+10);
        }
    document.getElementById('scoreArea').innerHTML = output;
}
*/

/* ********************** 
    HIER GAAT HET FOUT AANGEZIEN HIJ BIJ 12 MATCH STOP,
    HIER ZOU IK MISSCHIEN MOETEN WERKEN MET EEN INDEX EN EEN LUS OM ELKE KEER DE [I] ALS ARRAY TE GEBRUIKEN...
    EN MISSCHIEN DE EERSTE LETTER VAN HET WOORD (k)/(l)array TE VERVANGEN...
    
    WEET NIET EXACT HOE HET OPLOSSEN OM ZO VERSCHILLENDE LEVELS MET 1 ALGORITME AAN TE MAKEN
    MAAR HIER TOON IK GEWOON DAT IK SNAP HOE JE EEN EXTRA LEVEL TOEVOEGD OP HET EINDE VAN EEN AFGEWERKTE LUS....
    
****************************** */

function Opnieuw1(){
	KaartOmgedraaid = 0;
	var output = '';
    larray.Verdeel();
	for(var i = 0; i < larray.length; i++){
		output += '<div id="kaart-'+i+'" onclick="Retournement(this,\''+larray[i]+'\')"></div>';
	}
	document.getElementById('gameArea').innerHTML = output;
}

/* ********************** 
    DEZE FUNCTIE WERKT PERFECT ZOALS HET ZOU MOETEN.
********************** */
function Opnieuw(){
	KaartOmgedraaid = 0;
	var output = '';
    karray.Verdeel();
	for(var i = 0; i < karray.length; i++){
		output += '<div id="kaart-'+i+'" onclick="Retournement(this,\''+karray[i]+'\')"></div>';
	}
	document.getElementById('gameArea').innerHTML = output;
}

/* ********************** 
    DEZE FUNCTIE WERKT PERFECT ZOALS HET ZOU MOETEN.
********************** */

function Retournement(carte,val){
	if(carte.innerHTML == "" && Waarde.length < 2)
    {
		carte.style.background = 'darkgray';
        carte.style.color="yellow";
		carte.innerHTML = val;
            if(Waarde.length == 0)
                {
                Waarde.push(val);
                nrKaart.push(carte.id);
                } 
        else if(Waarde.length == 1)
        {
                Waarde.push(val);
                nrKaart.push(carte.id);
                if(Waarde[0] == Waarde[1])
                {
                    KaartOmgedraaid += 2;
                    Waarde = [];
                    nrKaart = [];

                    if(KaartOmgedraaid == karray.length)
                        {
                        alert("Winaar !!! .. Ga naar volgende level ???");
                        document.getElementById('gameArea').innerHTML = "";
                        Opnieuw1();
                        }
                } 
                else 
                {
                    function RemetreSurLeDos()
                        {
                        var carte_1 = document.getElementById(nrKaart[0]);
                        var carte_2 = document.getElementById(nrKaart[1]);
                        carte_1.style.background = 'url(../img/cb-4.jpg) no-repeat';
                        carte_1.innerHTML = "";
                        carte_2.style.background = 'url(../img/cb-4.jpg) no-repeat';
                        carte_2.innerHTML = "";
                        Waarde = [];
                        nrKaart = [];  
                        }
                    setTimeout(RemetreSurLeDos, 500);               
                 }
            }
	}
}
