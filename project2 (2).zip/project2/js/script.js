 "use strict";

    var off = true;
  var bcksound  = new Audio("../sounds/start.mp3");
    

$(function()
  {
    
    
/* --------------------- START --------------------- */
    
    

    $(document).ready(function () 
    {       
        $("#start").fadeIn(0);
        bcksound.play();
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeOut(0);
        
    
        
    });

    
/* --------------------- Buttons  --------------------- */
    
    
    
    $("#btnplay").click(function()
    {
        $("#start").fadeOut(0);
        $("#pageLevel").fadeIn(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeOut(0);

            
    });
    
     $("#lvl1").click(function()
    {
        $("#start").fadeOut(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeIn(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeOut(0);
    });
    
     $("#lvl2").click(function()
    {
        $("#start").fadeOut(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeIn(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeOut(0);
    });
    
     $("#lvl3").click(function()
    {
        $("#start").fadeOut(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeIn(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeIn(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeOut(0);
    });
    
    $("#btnContinue1").click(function()
    {
        $("#start").fadeOut(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeIn(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeOut(0);
        showrandom();
        
        /* practice mode show where the chrono will be */
        document.getElementById("chrono").value = "Chrono";
        document.getElementById("chrono").style.backgroundColor ="yellow";
        
        /* practice mode show where the score will be */
        document.getElementById("txtScore").value = "score";
        document.getElementById("txtScore").style.backgroundColor ="yellow";
        
        /* practice mode show where the "nr good answers" are */
        document.getElementById("txtbonneRep").value="Nr Bonne reponses";
        document.getElementById("txtbonneRep").style.backgroundColor="yellow";
        
        toonHarten(3);
        

            
    });
    
       $("#btnContinue2").click(function()
    {
        $("#start").fadeOut(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeIn(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeOut(0);
           
        toonHarten2(3);
        showrandom2();
        seconde2 = 120;
        score = 0;

            
    });
    
        
       $("#btnContinue3").click(function()
    {
        $("#start").fadeOut(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeIn(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeOut(0);
           
       
        toonHarten3(3);
        showrandom3();
        seconde3 = 240;
        score = 0;

            
    });
    
    $("#btnExit").click(function()
    {
        $("#start").fadeOut(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeIn(0);
        
    });
    
     $("#btnExit2").click(function()
    {
        $("#start").fadeOut(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeIn(0);
        
    });
    
     $("#btnExit3").click(function()
    {
        $("#start").fadeOut(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeIn(0);
        
    });
    
     $("#backMenu").click(function()
    {
        $("#start").fadeIn(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeOut(0);
        
        seconde2 = 3600;
        seconde3 = 3600;
        
    });


});

/* --------------------- LVL 1  --------------------- */

/* TIMER STAAT NIET AAN OP LVL 1 */


/*
var seconde;
setInterval(tijd,1000);

function tijd(){

    if(seconde > 0)
    {
        seconde -=1;
    document.getElementById("chrono").value = "Chrono";
       /* document.getElementById("chrono").innerHTML = seconde; *//*
    }

}
*/
function co()
{
    return Math.floor(Math.random() * 10) + 1
}


function showrandom(){
    /*
    var cijfers = 10;
    var c = cijfers.toString();
    */
    document.getElementById("Text1").value = co();
    document.getElementById("Text2").value = co();
}

function toonHarten(aant){
    var tText ="";
    for(var i = 0; i<aant;i++){
        tText += '<img src="../img/coeur.png" width="30px" height="30px">';
    }
    $("#livesArea").html(tText);
}

    var aantalVragenPerLevel = 10;
    var score = 0;

function check()
{
    aantalVragenPerLevel -=1;
    
    
    var first_number = parseInt(document.getElementById("Text1").value);
    var second_number = parseInt(document.getElementById("Text2").value);
    var result = first_number + second_number;
    
    
    var antwoord = parseInt(document.getElementById("txtAntwoord").value);
    
    if (result == antwoord)
    {
        document.getElementById("txtOKLM").value = "Bien Joué";
        document.getElementById("txtOKLM").style.backgroundColor ="green";
        
        toonHarten(4);
        /*score +=10;*/
       /* seconde +=3;*/
        
        document.getElementById("txtAntwoord").value = "";
        document.getElementById("txtAntwoord").focus();
        document.getElementById("txtAntwoord").select();
        
        
        showrandom();
    }
    else
    {
        document.getElementById("txtOKLM").value = "Mauvaise reponse";
        document.getElementById("txtOKLM").style.backgroundColor="red"; 
        
        toonHarten(3);
        /*score -=5; */
    }
    
    document.getElementById("txtScore").value = score;
}


/* ------------------------ LVL2 ------------------------ */

var seconde2 = 3600; 
/* deze blijft standaard zodat de spel na 1 uur uitvalt */
setInterval(tijd2,1000);

var bonneRep2 =0;


function tijd2(){

    if(seconde2 > 0)
    {
        seconde2 -=1;
        document.getElementById("chrono(2)").value = seconde2;
    }
    else
    {
        
        bonneRep2 =0;
        score = 0;
        
        $("#start").fadeOut(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeIn(0);
    }
    

}

function co2()
{
    return Math.floor(Math.random() * 1000) + 1
}

function showrandom2(){
    document.getElementById("Text1(2)").value = co2();
    document.getElementById("Text2(2)").value = co2();
}

function toonHarten2(aant2){
    var tText2 ="";
    for(var i = 0; i<aant2;i++){
        tText2 += '<img src="../img/coeur.png" width="30px" height="30px">';
    }
    $("#livesArea2").html(tText2);
}

    var score = 0;

function checkLvl2()
{
    document.getElementById("txtOKLM(2)").style.backgroundColor = "white";
    
    
    var first_number = parseInt(document.getElementById("Text1(2)").value);
    var second_number = parseInt(document.getElementById("Text2(2)").value);
    var result = first_number + second_number;
    
    
    var antwoord = parseInt(document.getElementById("txtAntwoord(2)").value);
    
    if (result == antwoord)
    {
        
        document.getElementById("txtOKLM(2)").value = "Bien Joué";
        document.getElementById("txtOKLM(2)").style.backgroundColor ="green";
        
        document.getElementById("txtAntwoord(2)").value = "";
        document.getElementById("txtAntwoord(2)").focus();
        document.getElementById("txtAntwoord(2)").select();
        
        toonHarten2(4);
        
        score +=10;
        seconde2 +=3;
        
        /* 10 juiste aantwoorden*/
        if(bonneRep2 < 9)
        {
            bonneRep2 +=1;
            document.getElementById("txtbonneRep(2)").value = bonneRep2;
        }
        else
        {
            
            
        $("#start").fadeOut(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeIn(0);
        $("#gameover").fadeOut(0);
        
            seconde2=3600;
            
        }
        
        showrandom2();
        
    }
    else
    {
        document.getElementById("txtOKLM(2)").value = "Mauvaise reponse";
        document.getElementById("txtOKLM(2)").style.backgroundColor ="red";
        
        toonHarten2(3);
        
        score -=5; 
    }
    
    document.getElementById("txtScore(2)").value = score;
}


/* ------------------------ LVL3 ------------------------ */

var seconde3 = 3600;
setInterval(tijd3,1000);

var bonneRep3 =0;

function tijd3(){

    if(seconde3 > 0)
    {
        seconde3 -=1;
        document.getElementById("chrono(3)").value = seconde3;
    }
    else
    {
        bonneRep3=0;
        score = 0;
        
        $("#start").fadeOut(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeIn(0);
    }

}

function co3()
{
    return Math.floor(Math.random() * 10000) + 1
}

function showrandom3(){
    document.getElementById("Text1(3)").value = co3();
    document.getElementById("Text2(3)").value = co3();
}

function toonHarten3(aant3){
    var tText3 ="";
    for(var i = 0; i<aant3;i++){
        tText3 += '<img src="../img/coeur.png" width="30px" height="30px">';
    }
    $("#livesArea3").html(tText3);
}

    var score = 0;

function checkLvl3()
{
    var first_number = parseInt(document.getElementById("Text1(3)").value);
    var second_number = parseInt(document.getElementById("Text2(3)").value);
    var result = first_number + second_number;
    
    
    var antwoord = parseInt(document.getElementById("txtAntwoord(3)").value);
    
    
    if (result == antwoord)
    {
        document.getElementById("txtOKLM(3)").value = "Bien joué";
        document.getElementById("txtOKLM(3)").style.backgroundColor="green";

        document.getElementById("txtAntwoord(3)").value = "";
        
        document.getElementById("txtAntwoord(3)").focus();
        document.getElementById("txtAntwoord(3)").select();

        toonHarten3(4);
        
        /* 10 juiste aantwoorden, complexer bij fouten */
        if(bonneRep3 < 9)
        {
            bonneRep3 +=1;
            document.getElementById("txtbonneRep(3)").value = bonneRep3;
        }
        else
        {
            
        $("#start").fadeOut(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeIn(0);
        $("#gameover").fadeOut(0);
        
            score = 0;
            bonneRep3 = 0;
            document.getElementById("txtOKLM(3)").value ="";
            document.getElementById("txtOKLM(3)").style.backgroundColor="white";
            seconde3=3600;   
        }
        
        score +=10;
        seconde3 +=3;
        showrandom3();
    }
    else
    {
        
         document.getElementById("txtOKLM(3)").value = "Reesayez";
        document.getElementById("txtOKLM(3)").style.backgroundColor="red";
        
        toonHarten3(3);
        
        score -=5; 
        
         if(bonneRep3 >0)
        {
            bonneRep3 -=1;
            document.getElementById("txtbonneRep(3)").value = bonneRep3;
        }
        else
        {
        
        $("#start").fadeOut(0);
        $("#pageLevel").fadeOut(0);
        $("#pageInfo1").fadeOut(0);
        $("#pageInfo2").fadeOut(0);
        $("#pageInfo3").fadeOut(0);
        $("#pageGame").fadeOut(0);
        $("#pageGame2").fadeOut(0);
        $("#pageGame3").fadeOut(0);
        $("#victoire").fadeOut(0);
        $("#gameover").fadeIn(0);
        
            score=0;
            
            document.getElementById("txtOKLM(3)").value="";
            document.getElementById("txtOKLM(3)").style.backgroundColor="white";
            seconde3=3600;  
        }

       
    }
    
    document.getElementById("txtScore(3)").value = score;
}

/* ------------------------ MUSIC ------------------------ */


$(function disco()
{
    $("#music").click(function() 
{
    if (off == true)
	{		
		bcksound.pause();
		$("#music").attr("src","../img/soundoff.png");
		off = false;
	}
	else
	{
		bcksound.play();
		$("#music").attr("src","../img/son.png");
		off = true;
	}
        
    })
});


      
